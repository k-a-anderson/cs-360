package com.example.weighttracker;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import android.util.Log;


public class NotificationsActivity extends AppCompatActivity {

    private DatabaseHelper db;
    private long userId;

    private TextView textPermissionStatus;
    private EditText editPhoneNumber;
    private EditText editGoalWeight;
    private Switch switchGoalAlert;
    private Button buttonRequestSms;

    private SharedPreferences prefs;

    private static final String TAG = "WT_SMS";


    private final ActivityResultLauncher<String> smsPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
                updatePermissionStatus();
                if (isGranted) {
                    Toast.makeText(this, "SMS permission granted.", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "SMS permission denied. App will work without SMS alerts.", Toast.LENGTH_LONG).show();
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }
        setContentView(R.layout.activity_notifications);

        db = new DatabaseHelper(this);
        prefs = getSharedPreferences("WT_PREFS", MODE_PRIVATE);

        userId = getIntent().getLongExtra("USER_ID", -1);
        if (userId == -1) {
            Toast.makeText(this, "User session error.", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        textPermissionStatus = findViewById(R.id.textPermissionStatus);
        editPhoneNumber = findViewById(R.id.editPhoneNumber);
        editGoalWeight = findViewById(R.id.editGoalWeight);
        switchGoalAlert = findViewById(R.id.switchGoalAlert);
        buttonRequestSms = findViewById(R.id.buttonRequestSms);
        Button buttonTestSms = findViewById(R.id.buttonTestSms);
        buttonTestSms.setOnClickListener(v -> sendTestSms());


        // Load saved settings
        editPhoneNumber.setText(prefs.getString("PHONE_" + userId, ""));
        switchGoalAlert.setChecked(prefs.getBoolean("ALERTS_" + userId, false));

        Double goal = db.getGoalWeight(userId);
        if (goal != null) {
            editGoalWeight.setText(String.valueOf(goal));
        }

        updatePermissionStatus();

        buttonRequestSms.setOnClickListener(v -> requestSmsPermission());

        // Save settings when user leaves the screen (simple approach)
        findViewById(android.R.id.content).setOnFocusChangeListener((v, hasFocus) -> {
            if (!hasFocus) saveSettings();
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        saveSettings();
    }

    private void updatePermissionStatus() {
        int result = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS);
        boolean granted = (result == PackageManager.PERMISSION_GRANTED);
        textPermissionStatus.setText(granted ? " Granted" : " Not granted");
    }

    private void requestSmsPermission() {
        int result = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS);
        if (result == PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Permission already granted.", Toast.LENGTH_SHORT).show();
            updatePermissionStatus();
            return;
        }
        smsPermissionLauncher.launch(Manifest.permission.SEND_SMS);
    }

    private void sendTestSms() {
        saveSettings(); // ensure phone/goal/toggle are stored before testing

        boolean alertsEnabled = switchGoalAlert.isChecked();
        String phone = editPhoneNumber.getText().toString().trim();

        if (!alertsEnabled) {
            Toast.makeText(this, "Enable the alert toggle first.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (phone.isEmpty()) {
            Toast.makeText(this, "Enter a phone number for alerts.", Toast.LENGTH_SHORT).show();
            return;
        }

        int perm = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS);
        if (perm != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "SMS permission not granted. Tap Request SMS Permission.", Toast.LENGTH_LONG).show();
            Log.d(TAG, "Test SMS blocked: permission not granted");
            return;
        }

        String msg = "Test: Weight Tracker SMS notifications are enabled.";
        try {
            SmsManager.getDefault().sendTextMessage(phone, null, msg, null, null);
            Toast.makeText(this, "Test SMS sent (or attempted). Check Logcat.", Toast.LENGTH_LONG).show();
            Log.d(TAG, "Test SMS sent to: " + phone);
        } catch (Exception e) {
            Toast.makeText(this, "SMS failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
            Log.e(TAG, "Test SMS failed", e);
        }
    }


    private void saveSettings() {
        // Save phone + switch in SharedPreferences
        String phone = editPhoneNumber.getText().toString().trim();
        boolean alertsEnabled = switchGoalAlert.isChecked();

        prefs.edit()
                .putString("PHONE_" + userId, phone)
                .putBoolean("ALERTS_" + userId, alertsEnabled)
                .apply();

        // Save goal in DB
        String goalText = editGoalWeight.getText().toString().trim();
        if (!goalText.isEmpty()) {
            try {
                double goalVal = Double.parseDouble(goalText);
                db.setGoalWeight(userId, goalVal);
            } catch (NumberFormatException ignored) { }
        }
    }
}
