package com.example.weighttracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "weighttracker.db";
    private static final int DB_VERSION = 1;

    // Tables
    public static final String TABLE_USERS = "users";
    public static final String TABLE_WEIGHTS = "weights";
    public static final String TABLE_GOAL = "goal_weight";

    // Common columns
    public static final String COL_ID = "_id";

    // users columns
    public static final String COL_USERNAME = "username";
    public static final String COL_PASSWORD = "password";

    // weights columns
    public static final String COL_USER_ID = "user_id";
    public static final String COL_DATE = "date_text";     // store as TEXT (e.g., "2025-03-05")
    public static final String COL_WEIGHT = "weight_value"; // REAL

    // goal columns
    public static final String COL_GOAL = "goal_value";     // REAL

    public DatabaseHelper(@Nullable Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createUsers =
                "CREATE TABLE " + TABLE_USERS + " (" +
                        COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        COL_USERNAME + " TEXT UNIQUE NOT NULL, " +
                        COL_PASSWORD + " TEXT NOT NULL" +
                        ");";

        String createWeights =
                "CREATE TABLE " + TABLE_WEIGHTS + " (" +
                        COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        COL_USER_ID + " INTEGER NOT NULL, " +
                        COL_DATE + " TEXT NOT NULL, " +
                        COL_WEIGHT + " REAL NOT NULL, " +
                        "FOREIGN KEY(" + COL_USER_ID + ") REFERENCES " + TABLE_USERS + "(" + COL_ID + ")" +
                        ");";

        String createGoal =
                "CREATE TABLE " + TABLE_GOAL + " (" +
                        COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        COL_USER_ID + " INTEGER UNIQUE NOT NULL, " +   // one goal per user
                        COL_GOAL + " REAL NOT NULL, " +
                        "FOREIGN KEY(" + COL_USER_ID + ") REFERENCES " + TABLE_USERS + "(" + COL_ID + ")" +
                        ");";

        db.execSQL(createUsers);
        db.execSQL(createWeights);
        db.execSQL(createGoal);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Simple for this course: wipe and recreate
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_GOAL);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WEIGHTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        onCreate(db);
    }

    // -------------------------
    // USERS: login / create
    // -------------------------

    /** Returns userId if username+password match, else -1 */
    public long validateLogin(String username, String password) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(
                TABLE_USERS,
                new String[]{COL_ID},
                COL_USERNAME + "=? AND " + COL_PASSWORD + "=?",
                new String[]{username, password},
                null, null, null
        );

        long userId = -1;
        if (c.moveToFirst()) {
            userId = c.getLong(0);
        }
        c.close();
        return userId;
    }

    /** Creates user if username not taken. Returns new userId, or -1 if failed */
    public long createUser(String username, String password) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_USERNAME, username);
        cv.put(COL_PASSWORD, password);
        return db.insert(TABLE_USERS, null, cv); // returns -1 if insert fails
    }

    /** Returns true if username exists */
    public boolean usernameExists(String username) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(TABLE_USERS, new String[]{COL_ID}, COL_USERNAME + "=?",
                new String[]{username}, null, null, null);
        boolean exists = c.moveToFirst();
        c.close();
        return exists;
    }

    // -------------------------
    // GOAL: set / get
    // -------------------------

    public boolean setGoalWeight(long userId, double goal) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_USER_ID, userId);
        cv.put(COL_GOAL, goal);

        // insert or replace (one goal per user)
        long rowId = db.insertWithOnConflict(TABLE_GOAL, null, cv, SQLiteDatabase.CONFLICT_REPLACE);
        return rowId != -1;
    }

    /** Returns goal weight, or null if not set */
    public Double getGoalWeight(long userId) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(TABLE_GOAL, new String[]{COL_GOAL},
                COL_USER_ID + "=?", new String[]{String.valueOf(userId)},
                null, null, null);

        Double goal = null;
        if (c.moveToFirst()) {
            goal = c.getDouble(0);
        }
        c.close();
        return goal;
    }

    // -------------------------
    // WEIGHTS: CRUD
    // -------------------------

    public long addWeight(long userId, String dateText, double weight) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_USER_ID, userId);
        cv.put(COL_DATE, dateText);
        cv.put(COL_WEIGHT, weight);
        return db.insert(TABLE_WEIGHTS, null, cv);
    }

    public Cursor getAllWeightsForUser(long userId) {
        SQLiteDatabase db = getReadableDatabase();
        return db.query(
                TABLE_WEIGHTS,
                new String[]{COL_ID, COL_DATE, COL_WEIGHT},
                COL_USER_ID + "=?",
                new String[]{String.valueOf(userId)},
                null, null,
                COL_DATE + " DESC"
        );
    }

    public boolean deleteWeight(long weightRowId) {
        SQLiteDatabase db = getWritableDatabase();
        int rows = db.delete(TABLE_WEIGHTS, COL_ID + "=?",
                new String[]{String.valueOf(weightRowId)});
        return rows > 0;
    }

    public boolean updateWeight(long weightRowId, double newWeight) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_WEIGHT, newWeight);
        int rows = db.update(TABLE_WEIGHTS, cv, COL_ID + "=?",
                new String[]{String.valueOf(weightRowId)});
        return rows > 0;
    }
}
