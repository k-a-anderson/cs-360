package com.example.weighttracker;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.text.InputType;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import android.util.Log;

import androidx.core.content.ContextCompat;


public class WeightListActivity extends AppCompatActivity {

    private DatabaseHelper db;
    private long userId;

    private TextView textGoalSummary;
    private TableLayout tableWeights;
    private EditText editNewWeight;
    private Button buttonAddWeight;
    private Button buttonNotifications;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }
        setContentView(R.layout.activity_weight_list);

        db = new DatabaseHelper(this);

        // USER_ID passed from LoginActivity
        userId = getIntent().getLongExtra("USER_ID", -1);
        if (userId == -1) {
            Toast.makeText(this, "User session error. Please log in again.", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        textGoalSummary = findViewById(R.id.textGoalSummary);
        tableWeights = findViewById(R.id.tableWeights);
        editNewWeight = findViewById(R.id.editNewWeight);
        buttonAddWeight = findViewById(R.id.buttonAddWeight);
        buttonNotifications = findViewById(R.id.buttonNotifications);

        buttonAddWeight.setOnClickListener(view -> addWeight());

        buttonNotifications.setOnClickListener(view -> {
            Intent intent = new Intent(WeightListActivity.this, NotificationsActivity.class);
            intent.putExtra("USER_ID", userId);
            startActivity(intent);
        });

        refreshGoalSummary();
        refreshWeightTable();
    }

    private void refreshGoalSummary() {
        Double goal = db.getGoalWeight(userId);
        if (goal == null) {
            textGoalSummary.setText("Goal: Not set");
        } else {
            textGoalSummary.setText("Goal: " + goal + " lbs");
        }
    }

    private void addWeight() {
        String input = editNewWeight.getText().toString().trim();
        if (input.isEmpty()) {
            Toast.makeText(this, "Enter a weight.", Toast.LENGTH_SHORT).show();
            return;
        }

        double weightValue;
        try {
            weightValue = Double.parseDouble(input);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Weight must be a number.", Toast.LENGTH_SHORT).show();
            return;
        }

        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
        long rowId = db.addWeight(userId, today, weightValue);

        if (rowId == -1) {
            Toast.makeText(this, "Failed to add weight.", Toast.LENGTH_SHORT).show();
            return;
        }

        editNewWeight.setText("");
        refreshWeightTable();
        refreshGoalSummary();
        checkGoalAndSendSmsIfAllowed(weightValue);

    }

    private void refreshWeightTable() {
        // Keep header row (index 0), remove everything below it
        while (tableWeights.getChildCount() > 1) {
            tableWeights.removeViewAt(1);
        }

        Cursor c = db.getAllWeightsForUser(userId);
        if (c == null) return;

        int colId = c.getColumnIndexOrThrow(DatabaseHelper.COL_ID);
        int colDate = c.getColumnIndexOrThrow(DatabaseHelper.COL_DATE);
        int colWeight = c.getColumnIndexOrThrow(DatabaseHelper.COL_WEIGHT);

        while (c.moveToNext()) {
            long weightRowId = c.getLong(colId);
            String dateText = c.getString(colDate);
            double weightValue = c.getDouble(colWeight);

            TableRow row = new TableRow(this);
            row.setPadding(8, 8, 8, 8);

            TextView dateView = new TextView(this);
            dateView.setText(dateText);
            dateView.setLayoutParams(new TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, 1f));

            TextView weightView = new TextView(this);
            weightView.setText(String.valueOf(weightValue));
            weightView.setLayoutParams(new TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, 1f));
            weightView.setPadding(16, 0, 16, 0);

            // Tap weight to update (Update requirement)
            weightView.setOnClickListener(view -> showUpdateDialog(weightRowId, weightValue));

            Button deleteButton = new Button(this);
            deleteButton.setText("Delete");
            deleteButton.setOnClickListener(view -> {
                boolean deleted = db.deleteWeight(weightRowId);
                if (deleted) {
                    refreshWeightTable();
                } else {
                    Toast.makeText(this, "Delete failed.", Toast.LENGTH_SHORT).show();
                }
            });

            row.addView(dateView);
            row.addView(weightView);
            row.addView(deleteButton);

            tableWeights.addView(row);
        }

        c.close();
    }

    private void showUpdateDialog(long weightRowId, double oldValue) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Update Weight");

        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        input.setText(String.valueOf(oldValue));
        builder.setView(input);

        builder.setPositiveButton("Save", (dialog, which) -> {
            String newText = input.getText().toString().trim();
            if (newText.isEmpty()) return;

            try {
                double newVal = Double.parseDouble(newText);
                boolean updated = db.updateWeight(weightRowId, newVal);
                if (updated) {
                    refreshWeightTable();
                    refreshGoalSummary();
                    checkGoalAndSendSmsIfAllowed(newVal);  // ✅ goal check happens here
                } else {
                    Toast.makeText(this, "Update failed.", Toast.LENGTH_SHORT).show();
                }
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Invalid number.", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss());
        builder.show();
    }
    private static final String TAG = "WT_SMS";

    private void checkGoalAndSendSmsIfAllowed(double currentWeight) {
        Double goal = db.getGoalWeight(userId);
        Log.d(TAG, "Goal check: current=" + currentWeight + ", goal=" + goal);

        if (goal == null) return;

        // Trigger when current <= goal
        if (currentWeight > goal) return;

        SharedPreferences prefs = getSharedPreferences("WT_PREFS", MODE_PRIVATE);
        boolean alertsEnabled = prefs.getBoolean("ALERTS_" + userId, false);
        String phone = prefs.getString("PHONE_" + userId, "").trim();

        if (!alertsEnabled) {
            Log.d(TAG, "Goal reached but alerts toggle OFF");
            Toast.makeText(this, "Goal reached! (alerts off)", Toast.LENGTH_LONG).show();
            return;
        }

        if (phone.isEmpty()) {
            Log.d(TAG, "Goal reached but phone is empty");
            Toast.makeText(this, "Goal reached! (no phone number set)", Toast.LENGTH_LONG).show();
            return;
        }

        int perm = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS);
        if (perm != PackageManager.PERMISSION_GRANTED) {
            Log.d(TAG, "Goal reached but SMS permission NOT granted");
            Toast.makeText(this, "Goal reached! (SMS permission not granted)", Toast.LENGTH_LONG).show();
            return;
        }

        String msg = "Congrats! You reached your goal weight of " + goal + " lbs.";
        try {
            SmsManager.getDefault().sendTextMessage(phone, null, msg, null, null);
            Log.d(TAG, "SMS send attempted to: " + phone);
            Toast.makeText(this, "Goal reached! SMS sent (or attempted).", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Log.e(TAG, "SMS failed", e);
            Toast.makeText(this, "Goal reached, but SMS failed.", Toast.LENGTH_LONG).show();
        }
    }
}
